CREATE VIEW int_history_rel AS SELECT int_scen_hist.id AS scenario_history_id,
    action_prm_hist.param_hist_id AS action_param_hist_id,
    action_hist.action_hist_id,
    dynmc_sql_hist.hist_id AS dynamic_sql_hist_id,
    validation_hist.hist_id AS validation_hist_id,
    event_hist.hist_id AS event_hist_id,
    cache_hist.id AS scen_cache_hist_id,
    ff_log.id AS flexi_field_hist_id
   FROM (((((((int_scenario_hist int_scen_hist
     LEFT JOIN int_action_parameter_hist action_prm_hist ON ((action_prm_hist.scen_hist_id = int_scen_hist.id)))
     LEFT JOIN int_action_hist action_hist ON ((action_hist.scen_hist_id = int_scen_hist.id)))
     LEFT JOIN int_dynmc_sql_hist dynmc_sql_hist ON ((dynmc_sql_hist.scen_hist_id = int_scen_hist.id)))
     LEFT JOIN int_validation_hist validation_hist ON ((validation_hist.scen_hist_id = int_scen_hist.id)))
     LEFT JOIN int_scen_event_hist event_hist ON ((event_hist.scen_hist_id = int_scen_hist.id)))
     LEFT JOIN int_scen_cache_hist cache_hist ON ((cache_hist.scen_hist_id = int_scen_hist.id)))
     LEFT JOIN int_ff_log_table ff_log ON ((ff_log.scen_hist_id = int_scen_hist.id)));
