CREATE VIEW v_all_scenario_states AS SELECT face_detected_demo_table.actorid,
    face_detected_demo_table.last_state,
    'Face_detected_demo'::character varying AS scenario_name
   FROM face_detected_demo_table;
